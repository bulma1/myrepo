const https = require('https');
const fs = require('fs');
const path = require('path');

// Create images/products directory if it doesn't exist
const dir = path.join(__dirname, 'images', 'products');
if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
}

// Image URLs from a reliable source
const imageUrls = {
    'black-pants.jpg': 'https://i.imgur.com/7KYtezP.jpg',  // Black pants image
    'cargo-pants.jpg': 'https://i.imgur.com/ZN3gqz5.jpg',  // Cargo pants image
    'polo.jpg': 'https://i.imgur.com/8dQ0waE.jpg',         // Polo shirt image
    'denim-shirt.jpg': 'https://i.imgur.com/L7gqDJU.jpg',  // Denim shirt image
    'sneakers.jpg': 'https://i.imgur.com/3VGqXD4.jpg',     // Sneakers image
    'formal-shoes.jpg': 'https://i.imgur.com/q1FbJ4z.jpg', // Formal shoes image
    'sunglasses.jpg': 'https://i.imgur.com/8wX2uA9.jpg',   // Sunglasses image
    'watch.jpg': 'https://i.imgur.com/ZW3kxvF.jpg',        // Watch image
    'jeans.jpg': 'https://i.imgur.com/YeZYXQx.jpg',        // Jeans image
    'tshirt.jpg': 'https://i.imgur.com/3dWQXYZ.jpg',       // White t-shirt image
    'shoes.jpg': 'https://i.imgur.com/kSf0IXc.jpg',        // Running shoes image
    'belt.jpg': 'https://i.imgur.com/5rF2pV4.jpg'          // Belt image
};

// Download function
function downloadImage(url, filename) {
    return new Promise((resolve, reject) => {
        const filepath = path.join(dir, filename);
        const file = fs.createWriteStream(filepath);

        https.get(url, response => {
            response.pipe(file);
            file.on('finish', () => {
                file.close();
                console.log(`Downloaded: ${filename}`);
                resolve();
            });
        }).on('error', err => {
            fs.unlink(filepath, () => {});
            console.error(`Error downloading ${filename}:`, err.message);
            reject(err);
        });
    });
}

// Download all images
async function downloadAllImages() {
    for (const [filename, url] of Object.entries(imageUrls)) {
        try {
            await downloadImage(url, filename);
        } catch (error) {
            console.error(`Failed to download ${filename}`);
        }
    }
}

downloadAllImages(); 
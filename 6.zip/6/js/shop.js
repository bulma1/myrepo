// Product data
const products = [
    // Pants
    {
        id: '1',
        name: 'Classic Blue Jeans',
        price: 59.99,
        category: 'pants',
        image: '../images/products/jeans.jpg',
        description: 'Classic fit blue jeans made from premium denim. Comfortable and durable.',
        sizes: ['30', '32', '34', '36', '38']
    },
    {
        id: '2',
        name: 'Black Slim Fit Pants',
        price: 49.99,
        category: 'pants',
        image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800',
        description: 'Classic black slim fit pants made from premium cotton blend. Perfect for both casual and formal occasions.',
        sizes: ['30', '32', '34', '36']
    },
    {
        id: '3',
        name: 'Cargo Pants',
        price: 54.99,
        category: 'pants',
        image: '../images/products/cargo-pants.jpg',
        description: 'Functional cargo pants with multiple pockets.',
        sizes: ['30', '32', '34', '36', '38']
    },

    // Shirts
    {
        id: '4',
        name: 'White T-Shirt',
        price: 24.99,
        category: 'shirts',
        image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800',
        description: 'Essential white t-shirt made from soft cotton. A versatile piece that goes with everything.',
        sizes: ['S', 'M', 'L', 'XL']
    },
    {
        id: '5',
        name: 'Polo Shirt',
        price: 34.99,
        category: 'shirts',
        image: '../images/products/polo.jpg',
        description: 'Classic polo shirt in breathable fabric.',
        sizes: ['S', 'M', 'L', 'XL', 'XXL']
    },
    {
        id: '6',
        name: 'Denim Shirt',
        price: 44.99,
        category: 'shirts',
        image: '../images/products/denim-shirt.jpg',
        description: 'Stylish denim shirt with pearl buttons.',
        sizes: ['S', 'M', 'L', 'XL']
    },

    // Shoes
    {
        id: '7',
        name: 'Running Shoes',
        price: 89.99,
        category: 'shoes',
        image: '../images/products/shoes.jpg',
        description: 'Comfortable running shoes with excellent cushioning and support.',
        sizes: ['7', '8', '9', '10', '11']
    },
    {
        id: '8',
        name: 'Casual Sneakers',
        price: 69.99,
        category: 'shoes',
        image: '../images/products/sneakers.jpg',
        description: 'Versatile sneakers for everyday wear.',
        sizes: ['7', '8', '9', '10', '11']
    },
    {
        id: '9',
        name: 'Formal Shoes',
        price: 99.99,
        category: 'shoes',
        image: '../images/products/formal-shoes.jpg',
        description: 'Elegant leather formal shoes.',
        sizes: ['7', '8', '9', '10', '11']
    },

    // Accessories
    {
        id: '10',
        name: 'Leather Belt',
        price: 29.99,
        category: 'accessories',
        image: '../images/products/belt.jpg',
        description: 'Genuine leather belt with classic buckle design.',
        sizes: ['30', '32', '34', '36']
    },
    {
        id: '11',
        name: 'Sunglasses',
        price: 39.99,
        category: 'accessories',
        image: '../images/products/sunglasses.jpg',
        description: 'UV protection sunglasses with modern design.',
        sizes: ['One Size']
    },
    {
        id: '12',
        name: 'Watch',
        price: 129.99,
        category: 'accessories',
        image: '../images/products/watch.jpg',
        description: 'Classic analog watch with leather strap.',
        sizes: ['One Size']
    }
];

// Display products
function displayProducts(productsToShow = products) {
    const productGrid = document.getElementById('productGrid');
    if (!productGrid) return;

    productGrid.innerHTML = '';
    productsToShow.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.innerHTML = `
            <div class="product-image-container" role="button" aria-label="View ${product.name} details">
                <img src="${product.image}" alt="${product.name}" class="product-image" loading="lazy">
                <div class="product-image-overlay">
                    <span>View Details</span>
                </div>
            </div>
            <div class="product-info">
                <h3 class="product-title">${product.name}</h3>
                <p class="product-price">$${product.price.toFixed(2)}</p>
                <button onclick="addToCart(${JSON.stringify(product)})" class="add-to-cart">
                    <i class="fas fa-shopping-cart"></i> Add to Cart
                </button>
            </div>
        `;
        productGrid.appendChild(productCard);

        // Add click event to the image container for product details
        productCard.querySelector('.product-image-container').addEventListener('click', () => {
            showProductDetails(product.id);
        });
    });
}

// Show product details
function showProductDetails(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const productDetail = document.getElementById('productDetail');
    if (!productDetail) return;

    productDetail.innerHTML = `
        <div class="product-detail-container">
            <img src="${product.image}" alt="${product.name}" class="product-detail-image">
            <div class="product-detail-info">
                <h2>${product.name}</h2>
                <p class="product-detail-price">$${product.price.toFixed(2)}</p>
                <p class="product-detail-description">${product.description}</p>
                <div class="product-detail-sizes">
                    <h3>Available Sizes:</h3>
                    <div class="size-buttons">
                        ${product.sizes.map(size => `
                            <button class="size-btn">${size}</button>
                        `).join('')}
                    </div>
                </div>
                <button onclick="addToCart(${JSON.stringify(product)})" class="add-to-cart-btn">
                    Add to Cart
                </button>
            </div>
        </div>
    `;

    openModal('productModal');
}

// Filter products by category
function filterProducts(category) {
    const filteredProducts = category === 'all' 
        ? products 
        : products.filter(product => product.category === category);
    displayProducts(filteredProducts);
}

// Search products
function searchProducts(searchTerm) {
    const filteredProducts = products.filter(product => 
        product.name.toLowerCase().includes(searchTerm) ||
        product.description.toLowerCase().includes(searchTerm)
    );
    displayProducts(filteredProducts);
}

// Category button click handlers
document.querySelectorAll('.category-btn').forEach(button => {
    button.addEventListener('click', () => {
        // Remove active class from all buttons
        document.querySelectorAll('.category-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        // Add active class to clicked button
        button.classList.add('active');
        // Filter products
        filterProducts(button.dataset.category);
    });
});

// Initialize shop page
document.addEventListener('DOMContentLoaded', () => {
    displayProducts();
}); 
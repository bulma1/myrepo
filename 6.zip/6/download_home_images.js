const https = require('https');
const fs = require('fs');
const path = require('path');

// Create images directory if it doesn't exist
const imagesDir = path.join(__dirname, 'images');
if (!fs.existsSync(imagesDir)) {
    fs.mkdirSync(imagesDir);
}

// Image URLs for the home page sections
const imageUrls = {
    'category-men.jpg': 'https://images.unsplash.com/photo-1490578474895-699cd4e2cf59?w=1200',
    'category-women.jpg': 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1200',
    'category-accessories.jpg': 'https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?w=1200',
    'summer-sale.jpg': 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=1200',
    'new-arrivals.jpg': 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=1200',
    'newsletter-bg.jpg': 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=1600'
};

function downloadImage(url, filename) {
    return new Promise((resolve, reject) => {
        const filepath = path.join(imagesDir, filename);
        const file = fs.createWriteStream(filepath);

        https.get(url, response => {
            response.pipe(file);
            file.on('finish', () => {
                file.close();
                console.log(`Downloaded: ${filename}`);
                resolve();
            });
        }).on('error', err => {
            fs.unlink(filepath, () => reject(err));
        });
    });
}

async function downloadAllImages() {
    for (const [filename, url] of Object.entries(imageUrls)) {
        try {
            await downloadImage(url, filename);
        } catch (error) {
            console.error(`Error downloading ${filename}:`, error);
        }
    }
}

downloadAllImages(); 